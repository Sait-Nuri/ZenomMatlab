/*
 * deneme_capi.h
 *
 * Code generation for model "deneme".
 *
 * Model version              : 1.8
 * Simulink Coder version : 8.6 (R2014a) 27-Dec-2013
 * C source code generated on : Mon Aug 10 17:05:58 2015
 *
 * Target selection: zenom.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef _RTW_HEADER_deneme_capi_h_
#define _RTW_HEADER_deneme_capi_h_
#include "deneme.h"

extern void deneme_InitializeDataMapInfo(RT_MODEL_deneme_T *const deneme_M
  );

#endif                                 /* _RTW_HEADER_deneme_capi_h_ */

/* EOF: deneme_capi.h */
