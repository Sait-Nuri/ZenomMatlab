/*
 * deneme_types.h
 *
 * Code generation for model "deneme".
 *
 * Model version              : 1.8
 * Simulink Coder version : 8.6 (R2014a) 27-Dec-2013
 * C source code generated on : Mon Aug 10 17:05:58 2015
 *
 * Target selection: zenom.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */
#ifndef RTW_HEADER_deneme_types_h_
#define RTW_HEADER_deneme_types_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"

/* Parameters (auto storage) */
typedef struct P_deneme_T_ P_deneme_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_deneme_T RT_MODEL_deneme_T;

#endif                                 /* RTW_HEADER_deneme_types_h_ */
